gamma = 0.999
delta = 0.001

step_cost = -20

T2C1 = False
T2C2 = False
